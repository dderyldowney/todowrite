"""Schema validation tests module."""
